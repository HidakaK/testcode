﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {/// <summary>
    /// time show hensuu
    /// </summary>
        private DispatcherTimer timer;
        public MainWindow()
        {
            InitializeComponent();
            timer = CreateTimer();
        }

        private DispatcherTimer CreateTimer()
        {
            var t = new DispatcherTimer(DispatcherPriority.SystemIdle);
            t.Interval = TimeSpan.FromMilliseconds(300);
            t.Tick += (sender, e) =>
            {
                TextBlock.Text = DateTime.Now.ToString("HH:mm:ss");
            };
            return t;
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            timer.Start();
        }
    }
}
